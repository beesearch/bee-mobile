/*
 * config/interceptors.js
 *
 * Defines the interceptors for the application.
 *
 */
// Interceptor catching 401 responses
angular.module(_APP_).config(function($httpProvider) {
  var responseInterceptor = function($q) {
    return {
      response: function (response) {
        // do something on success
        return response;
      },
      responseError: function (response) {
        // do something on error
        console.log('HTTP interceptor responseError:' + JSON.stringify(response));
        if(response.status === 401){
          // TODO: Refresh token ?
          $location.path('/login');
          return $q.reject(response);
        } else {
          return $q.reject(response);
        }
      }
    }
  };

  $httpProvider.interceptors.push(responseInterceptor);
});

/*
 * config/router.js
 *
 * Defines the routes for the application.
 *
 */
 angular.module(_APP_).config([
  '$routeProvider',
  function($routeProvider) {

    // Define routes here.
    $routeProvider
    .when('/', { 
      templateUrl: 'html/partials/home/index.html', 
      controller: 'HomeController' 
    })
    .when('/login', { 
      templateUrl: 'html/partials/home/login.html', 
      controller: 'HomeLoginController' 
    })
    .when('/users', { 
      templateUrl: 'html/partials/users/list.html', 
      controller: 'UserListController' 
    })
    .when('/users/:userId', {
      templateUrl: 'html/partials/users/detail.html', 
      controller: 'UserDetailController'
    })
    .when('/products', { 
      templateUrl: 'html/partials/products/list.html', 
      controller: 'ProductListController' 
    })
    .when('/products/:productId', {
      templateUrl: 'html/partials/products/detail.html', 
      controller: 'ProductDetailController'
    })
    .when('/contacts', { 
      templateUrl: 'html/partials/contacts/list.html', 
      controller: 'ContactListController' 
    })
    .when('/notifications', {
      templateUrl: 'html/partials/phonegap/notifications.html', 
      controller: 'NotificationsController'
    })
    .when('/device', {
      templateUrl: 'html/partials/phonegap/device.html', 
      controller: 'DeviceController'
    })
    .otherwise({ redirectTo: '/' });
  }
  ]);

/*
 * config/sanitizer.js
 *
 * Defines the regex for link sanitation.
 *
 */
angular.module(_APP_).config([
  '$compileProvider',
  function($compileProvider) {

    // sanitize white list for angular/phonegap
    var sanitation = new RegExp('^\s*(https?|ftp|mailto|file|tel|comgooglemaps|sms):');
    $compileProvider.aHrefSanitizationWhitelist(sanitation);
  }
]);
