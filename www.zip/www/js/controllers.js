angular.module(_CONTROLLERS_).controller('ContactListController', [
  '$scope',
  'Contact',
  function ($scope, Contact) {
    console.log('### ContactListController in');
    $scope.isDropdownOpen = false;
    $scope.orderProp = 'lastName';
    $scope.orderBy = function (prop) {
      console.log('prop: ' + prop);
      $scope.orderProp = prop;
      $scope.isDropdownOpen = false;
    };
    var contact = Contact.get({ id: 1 }, function () {
        $scope.users = contact;
      });
    console.log('### ContactListController out');
  }
]);
angular.module(_CONTROLLERS_).controller('DeviceController', [
  '$scope',
  'notificationService',
  function ($scope, notificationService) {
    console.log('### DeviceController in');
    $scope.device = device;
    console.log('### DeviceController out');
  }
]);
angular.module(_CONTROLLERS_).controller('HomeController', [
  '$scope',
  function ($scope) {
    $scope.text = 'Hello World!';
  }
]);
angular.module(_CONTROLLERS_).controller('HomeLoginController', [
  '$scope',
  'oauth2Token',
  function ($scope, oauth2Token) {
    console.log('### HomeLoginController in');
    $scope.signin = function () {
      oauth2Token.retrieveToken();
    };
    console.log('### HomeLoginController out');
  }
]);
angular.module(_CONTROLLERS_).controller('NavigationController', [
  '$scope',
  '$location',
  function ($scope, $location) {
    $scope.isNavbarOpen = false;
    $scope.isActive = function (viewLocation) {
      return viewLocation === $location.path();
    };
    $scope.goto = function (viewLocation) {
      $location.path(viewLocation);
      $scope.isNavbarOpen = false;
    };
  }
]);
angular.module(_CONTROLLERS_).controller('NotificationsController', [
  '$scope',
  'notificationService',
  function ($scope, notificationService) {
    console.log('### NotificationController in');
    notificationService.alert('message', function () {
      alert('callback!');
    }, 'title', 'button name!');
    console.log('### NotificationController out');
  }
]);
angular.module(_CONTROLLERS_).controller('ProductListController', [
  '$scope',
  '$http',
  function ($scope, $http) {
    console.log('### ProductListControler in');
    $scope.isDropdownOpen = false;
    $scope.productProp = 'title';
    $scope.orderBy = function (prop) {
      console.log('prop: ' + prop);
      $scope.productProp = prop;
      $scope.isDropdownOpen = false;
    };
    $http.get('http://robbeehome.no-ip.biz:3302/album/listAllAlbum').success(function (data) {
      $scope.products = data;
    });
    console.log('### ProductListControler out');
  }
]);
angular.module(_CONTROLLERS_).controller('ProductDetailController', [
  '$scope',
  '$routeParams',
  '$http',
  function ($scope, $routeParams, $http) {
    console.log('### ProductDetailController in');
    var url = 'http://robbeehome.no-ip.biz:3302/album/findAlbumByAlbumId/' + $routeParams.productId;
    $http.get(url).success(function (data) {
      $scope.product = data;
    });
    var url = 'http://localhost:3302/track/findTrackByAlbumId/' + $routeParams.productId;
    $http.get(url).success(function (data) {
      $scope.tracks = data;
    });
    console.log('### ProductDetailController out');
  }
]);
angular.module(_CONTROLLERS_).controller('UserListController', [
  '$scope',
  '$http',
  function ($scope, $http) {
    console.log('### UserListControler in');
    $scope.isDropdownOpen = false;
    $scope.orderProp = 'lastName';
    $scope.orderBy = function (prop) {
      console.log('prop: ' + prop);
      $scope.orderProp = prop;
      $scope.isDropdownOpen = false;
    };
    $http.get('http://zenbox-demo.herokuapp.com/zenbox-demo/rest/users/list').success(function (data) {
      $scope.users = data;
    });
    console.log('### UserListControler out');
  }
]);
angular.module(_CONTROLLERS_).controller('UserDetailController', [
  '$scope',
  '$routeParams',
  '$http',
  function ($scope, $routeParams, $http) {
    console.log('### UserDetailController in');
    var url = 'http://zenbox-demo.herokuapp.com/zenbox-demo/rest/users/show/' + $routeParams.userId;
    $http.get(url).success(function (data) {
      $scope.user = data;
    });
    console.log('### UserDetailController out');
  }
]);