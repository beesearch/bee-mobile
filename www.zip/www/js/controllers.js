angular.module(_CONTROLLERS_).controller('ContactListController', [
  '$scope',
  'Contact',
  function ($scope, Contact) {
    console.log('### ContactListController in');
    $scope.isDropdownOpen = false;
    $scope.orderProp = 'lastName';
    $scope.orderBy = function (prop) {
      console.log('prop: ' + prop);
      $scope.orderProp = prop;
      $scope.isDropdownOpen = false;
    };
    var contact = Contact.get({ id: 1 }, function () {
        $scope.users = contact;
      });
    console.log('### ContactListController out');
  }
]);
angular.module(_CONTROLLERS_).controller('DeviceController', [
  '$scope',
  'notificationService',
  function ($scope, notificationService) {
    console.log('### DeviceController in');
    $scope.device = device;
    console.log('### DeviceController out');
  }
]);
angular.module(_CONTROLLERS_).controller('HomeController', [
  '$scope',
  function ($scope) {
    $scope.text = 'Hello World!';
  }
]);
angular.module(_CONTROLLERS_).controller('HomeLoginController', [
  '$scope',
  'oauth2Token',
  function ($scope, oauth2Token) {
    console.log('### HomeLoginController in');
    $scope.signin = function () {
      oauth2Token.retrieveToken();
    };
    console.log('### HomeLoginController out');
  }
]);
angular.module(_CONTROLLERS_).controller('NavigationController', [
  '$scope',
  '$location',
  function ($scope, $location) {
    $scope.isNavbarOpen = false;
    $scope.isActive = function (viewLocation) {
      return viewLocation === $location.path();
    };
    $scope.goto = function (viewLocation) {
      $location.path(viewLocation);
      $scope.isNavbarOpen = false;
    };
  }
]);
angular.module(_CONTROLLERS_).controller('NotificationsController', [
  '$scope',
  'notificationService',
  function ($scope, notificationService) {
    console.log('### NotificationController in');
    notificationService.alert('message', function () {
      alert('callback!');
    }, 'title', 'button name!');
    console.log('### NotificationController out');
  }
]);
angular.module(_CONTROLLERS_).controller('UserDetailController', [
  '$scope',
  '$routeParams',
  '$http',
  function ($scope, $routeParams, $http) {
    console.log('### UserDetailController in');
    var url = 'http://zenbox-demo.herokuapp.com/zenbox-demo/rest/users/show/' + $routeParams.userId;
    $http.get(url).success(function (data) {
      $scope.user = data;
    });
    console.log('### UserDetailController out');
  }
]);
angular.module(_CONTROLLERS_).controller('UserListController', [
  '$scope',
  '$http',
  function ($scope, $http) {
    console.log('### UserListControler in');
    $scope.isDropdownOpen = false;
    $scope.orderProp = 'lastName';
    $scope.orderBy = function (prop) {
      console.log('prop: ' + prop);
      $scope.orderProp = prop;
      $scope.isDropdownOpen = false;
    };
    $http.get('http://zenbox-demo.herokuapp.com/zenbox-demo/rest/users/list').success(function (data) {
      $scope.users = data;
    });
    console.log('### UserListControler out');
  }
]);