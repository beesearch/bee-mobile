/*
 * environments/development.js
 * This file defines globals that are used in a 
 * development environment.
 *
 * Example:
 * var _BASE_API_URL = 'http://dev.example.org/api/v1';
 *
 */
