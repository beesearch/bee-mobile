angular.module(_SERVICES_).factory('Contact', [
  '$resource',
  'oauth2Token',
  function ($resource, oauth2Token) {
    var resource = $resource('http://localhost:80/contacts/:id', { id: '@id' });
    resource = oauth2Token.wrapActions(resource, [
      'query',
      'get',
      'save',
      'delete'
    ]);
    return resource;
  }
]);
angular.module(_SERVICES_).factory('oauth2Token', [
  '$http',
  function ($http) {
    var oauth2Token = {};
    oauth2Token.set = function (token) {
      localStorage.access_token = token;
    };
    oauth2Token.get = function () {
      return localStorage.access_token;
    };
    oauth2Token.retrieveToken = function () {
      $http({
        method: 'POST',
        url: 'http://localhost/oauth/token',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': 'Basic czZCaGRSa3F0MzpnWDFmQmF0M2JW'
        },
        data: 'grant_type=password&username=johndoe&password=534b44a19bf18d20b71ecc4eb77c572f'
      }).success(function (data, status, headers, config) {
        console.log('data: ' + JSON.stringify(data) + ', status: ' + status);
        oauth2Token.set(data.access_token);
        console.log(localStorage.access_token);
      }).error(function (data, status, headers, config) {
        console.log('data: ' + JSON.stringify(data) + ', status: ' + status + ', config: ' + JSON.stringify(config));
      });
    };
    oauth2Token.wrapActions = function (resource, actions) {
      var wrappedResource = resource;
      for (var i = 0; i < actions.length; i++) {
        tokenWrapper(wrappedResource, actions[i]);
      }
      ;
      return wrappedResource;
    };
    var tokenWrapper = function (resource, action) {
      resource['_' + action] = resource[action];
      resource[action] = function (data, success, error) {
        return resource['_' + action](angular.extend({}, data || {}, { access_token: oauth2Token.get() }), success, error);
      };
    };
    return oauth2Token;
  }
]);
angular.module(_SERVICES_).factory('cordovaReady', function () {
  return function (fn) {
    var queue = [];
    var impl = function () {
      queue.push(Array.prototype.slice.call(arguments));
    };
    document.addEventListener('deviceready', function () {
      queue.forEach(function (args) {
        fn.apply(this, args);
      });
      impl = fn;
    }, false);
    return function () {
      return impl.apply(this, arguments);
    };
  };
});
angular.module(_SERVICES_).factory('geolocationService', [
  '$rootScope',
  'cordovaReady',
  function ($rootScope, cordovaReady) {
    return {
      getCurrentPosition: cordovaReady(function (onSuccess, onError, options) {
        navigator.geolocation.getCurrentPosition(function () {
          var that = this, args = arguments;
          if (onSuccess) {
            $rootScope.$apply(function () {
              onSuccess.apply(that, args);
            });
          }
        }, function () {
          var that = this, args = arguments;
          if (onError) {
            $rootScope.$apply(function () {
              onError.apply(that, args);
            });
          }
        }, options);
      })
    };
  }
]);
angular.module(_SERVICES_).factory('accelerometerService', [
  '$rootScope',
  'cordovaReady',
  function ($rootScope, cordovaReady) {
    return {
      getCurrentAcceleration: cordovaReady(function (onSuccess, onError) {
        navigator.accelerometer.getCurrentAcceleration(function () {
          var that = this, args = arguments;
          if (onSuccess) {
            $rootScope.$apply(function () {
              onSuccess.apply(that, args);
            });
          }
        }, function () {
          var that = this, args = arguments;
          if (onError) {
            $rootScope.$apply(function () {
              onError.apply(that, args);
            });
          }
        });
      })
    };
  }
]);
angular.module(_SERVICES_).factory('notificationService', [
  '$rootScope',
  'cordovaReady',
  function ($rootScope, cordovaReady) {
    return {
      alert: cordovaReady(function (message, alertCallback, title, buttonName) {
        navigator.notification.alert(message, function () {
          var that = this, args = arguments;
          $rootScope.$apply(function () {
            alertCallback.apply(that, args);
          });
        }, title, buttonName);
      }),
      confirm: cordovaReady(function (message, confirmCallback, title, buttonLabels) {
        navigator.notification.confirm(message, function () {
          var that = this, args = arguments;
          $rootScope.$apply(function () {
            confirmCallback.apply(that, args);
          });
        }, title, buttonLabels);
      }),
      beep: function (times) {
        navigator.notification.beep(times);
      },
      vibrate: function (milliseconds) {
        navigator.notification.vibrate(milliseconds);
      }
    };
  }
]);